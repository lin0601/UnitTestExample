# encoding: utf-8

# @Time : 2020/7/13 16:19
# @Author : linjian
import paramiko


class SshTool(object):

    def __init__(self, hostname, port, username, password):
        self.hostname = hostname
        self.port = port
        self.username = username
        self.password = password

    def create_ssh_object(self):
        """
        创建paramiko链接服务器实例
        @return:
        """
        # 实例化SSHClient
        client = paramiko.SSHClient()
        # 自动添加策略，保存服务器的主机名和密钥信息，如果不添加，那么不再本地know_hosts文件中记录的主机将无法连接
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # 连接SSH服务端，以用户名和密码进行认证
        # todo 这里需要加捕获错误
        client.connect(hostname=self.hostname, port=self.port, username=self.username, password=self.password)
        return client

    def ssh_operate(self, cmd):
        """
        实例操作
        @param cmd:命令
        @return:
        """
        client_obj = self.create_ssh_object()
        # 打开一个Channel并执行命令 stdout 为正确输出，stderr为错误输出，同时是有1个变量有值
        stdin, stdout, stderr = client_obj.exec_command(cmd)
        return stdin, stdout, stderr
