#!/usr/bin/env python
# *_* coding=utf8 *_*

# @Time : 2020/7/13 16:18
# @Author : linjian
import os
import unittest

# 当前工作目录
case_path = os.path.join(os.path.dirname(os.path.realpath(__file__)))
suit = unittest.TestSuite()
case_list = []

# 使用os.walk方法遍历得到所有文件名称filename的列表集合
for dirpath, dirname, filename in os.walk(case_path):
    for file in filename:
        # 判断文件（满足test开头， py结尾的）
        if file.endswith(".py") and file.startswith("test"):
            case_list.append(file)

# 得到有效的用例文件列表后传值给discover方法的pattern匹配方式，可拿到所有testcase
# 要想拿到所有的testcase必须在每个文件夹中有一个__init__.py文件引导，否则无法获取。
for case in case_list:
    discover = unittest.defaultTestLoader.discover(start_dir=case_path, pattern=case)
    suit.addTest(discover)

runner = unittest.TextTestRunner()  # 实例化运行类
runner.run(suit)  # 运行用例集，会根据添加的用例顺序进行用例的执行
