#!/usr/bin/env python
# *_* coding=utf8 *_*

# @Time : 2020/7/13 16:47
# @Author : linjian
import os
import unittest

# 获取当前工作目录
test_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)))
# 用discover的方法去覆盖所有的测试用例
# test_dir 要执行的测试用例目录
# test*表示匹配以test开头的所有.py文件
# top_level_dir=None 测试模块的顶级目录，没有的话就写None
discover = unittest.defaultTestLoader.discover(test_dir, pattern="test*.py", top_level_dir=None)
runner = unittest.TextTestRunner()  # 实例化runner类
runner.run(discover)  # 执行路径中匹配的所有test*.py用例
