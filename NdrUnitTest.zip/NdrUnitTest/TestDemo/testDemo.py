#!/usr/bin/env python
# *_* coding=utf8 *_*

# @Time : 2020/7/13 16:44
# @Author : linjian

import unittest
import time


class UtMber(unittest.TestCase):

    def setUp(self):
        pass

    def test_add(self):
        c = 1 + 1
        self.assertEqual(c, 2)

    def test_multiply(self):
        c = 1 * 2
        self.assertEqual(c, 2)

    # 跳过测试（参数是原因）
    @unittest.skip("我就是想跳过")
    def test_skip(self):
        self.assertEqual(1, 2)

    # 跳过测试（第一个参数是状态(布尔)，第二个原因）
    @unittest.skipIf(True, "我也想跳过测试")
    def test_skipif(self):
        self.assertEqual(1, 2)

    def tearDown(self):
        print ("我执行完了")
