#!/usr/bin/env python
# *_* coding=utf8 *_*

# @Time : 2020/7/13 17:23
# @Author : linjian


import unittest
import time


class UtMber(unittest.TestCase):

    def setUp(self):
        pass

    def test_subtraction(self):
        c = 6 - 4
        self.assertEqual(c, 2)
